const fetchCountries = async () => {
    const continent = document.getElementById("continent").value;
    const country = document.getElementById("country").value;
    let url = "https://restcountries.com/v3.1/all";

    if (country) {
        url = `https://restcountries.com/v3.1/name/${country}`;
    } else if (continent) {
        url = `https://restcountries.com/v3.1/region/${continent}`;
    }

    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`Error ${response.status}: No se pudo obtener los datos`);
        const data = await response.json();
        displayResults(data);
    } catch (error) {
        console.error("Error al obtener los datos:", error);
        document.getElementById("results").innerHTML = `<p style="color:red;">${error.message}</p>`;
    }
};

const displayResults = (countries) => {
    const resultsDiv = document.getElementById("results");
    resultsDiv.innerHTML = countries.map(({ name, capital, region, flags }) =>
        `<div class="card">
            <h3>${name.common}</h3>
            <p>Capital: ${capital ? capital[0] : "Desconocida"}</p>
            <p>Región: ${region}</p>
            <img src="${flags.svg}" alt="Bandera de ${name.common}">
        </div>`
    ).join('');
};

document.getElementById("searchBtn").addEventListener("click", fetchCountries);

