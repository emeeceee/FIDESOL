const query = new URLSearchParams(window.location.search)
const params = query.get('name')
console.log(params)

document.addEventListener("DOMContentLoaded", function (event) {
    console.log("DOM fully loaded and parsed");
    fetchData()
});

const fetchData = async () => {
    try {
        const res = await fetch(`https://restcountries.eu/rest/v2/name/${params}`)
        const data = await res.json()

        const filterData = data.filter(item => item.name === params)
        console.log(filterData)
        banderillas(filterData)
    } catch (error) {
        console.log(error)
    }
}

const bandera = document.getElementById('bandera')

const banderillas = (data) => {
    let elementos = ''
    for (let [index, item] of data.entries()) {
        elementos += `
        <div class="card">
        <img src="${item.flag}" alt="Bandera ${item.name}" class="img-fluid">
            <div class="card-content">
                <h3>${item.name}</h3>
                <p>
                    <b>Population: </b>
                    ${item.population}
                </p>
                <p>
                    <b>Region: </b>
                    ${item.region}
                </p>
                <p>
                    <b>Capital: </b>
                    ${item.capital}
                </p>
                <p>
                    <b>alpha3Code: </b>
                    ${item.alpha3Code}
                </p>
                <p>
                    <b>demonym: </b>
                    ${item.demonym}
                </p>
                <p>
                    <b>topLevelDomain: </b>
                    ${item.topLevelDomain[0]}
                </p>
            </div>
        </div>
        `
    }
    bandera.innerHTML = elementos
}