document.addEventListener("DOMContentLoaded", () => {
    const btnDark = document.querySelector('.btn-dark-mode');
    if (btnDark) {
        btnDark.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme');
            btnDark.innerHTML = document.body.classList.contains('dark-theme')
                ? `<i class="fas fa-sun"></i> Light Mode`
                : `<i class="fas fa-moon"></i> Dark Mode`;
        });
    } else {
        console.error("Error: No se encontró el botón btn-dark-mode");
    }
});
