const formulario = document.querySelector('#formulario');
const inputTexto = document.querySelector('#inputTexto');
let banderillas = (data) => {
    console.log(data);
};


const formularioReal = (data) => {
    // console.log(data)
    formulario.addEventListener('keyup', async (e) => {
        e.preventDefault()

        const textoCliente = inputTexto.value.toLowerCase()
        // console.log(textoCliente)

        const formularioFiltrado = data.filter(item => {
            const textoApi = item.name.toLowerCase()
            if (textoApi.indexOf(textoCliente) !== -1) {
                return item
            }
        })
        banderillas(formularioFiltrado)

    })
    banderas.innerHTML = elementos

}
let banderillas = (data) => {

    let elementos = ''

    for (let [index, item] of data.entries()) {
        // console.log(item)
        elementos += `
            <div class="card">
            <img src="${item.flag}" alt="Bandera ${item.name}" class="img-fluid">
                <div class="card-content">
                    <h3>${item.name}</h3>
                    <p>
                        <b>Population: </b>
                        ${item.population}
                    </p>
                    <p>
                        <b>Region: </b>
                        ${item.region}
                    </p>
                    <p>
                        <b>Capital: </b>
                        ${item.capital}
                    </p>
                    <p>
                        <a href="pais.html?name=${item.name}">${item.name}</a>
                    </p>
                </div>
            </div>
            `
    }

    banderas.innerHTML = elementos


}